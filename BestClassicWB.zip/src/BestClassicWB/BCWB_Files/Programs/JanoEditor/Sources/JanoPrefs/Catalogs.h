#define  CATCOMP_NUMBERS
#include "Prefs_Strings.h"
#define	LocaleInfo				LocaleInfoTmp		/* Avoid redefinition :-( */
#include "Jed_Strings.h"
